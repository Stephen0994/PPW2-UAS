<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" />
<style type="text/css">
	@font-face {
	  font-family: futura light;
	  src: url(<?= base_url()?>assets/fonts/futura light bt.ttf);
	  font-family: opensans;
	  src: url(<?= base_url()?>assets/fonts/OpenSans-Light.ttf);
	}

	#addTask {
	  margin-left: 17%;
	}

	.task a, td {
		background-color: transparent;
		text-align: left;
		border: 0;
	}

	.lbl, .tit {
		height: 20px;
	}

	.desc {
		height: 100px;
		width: 500px
	}

	#taskSave input {
	  color: black;
	  background-color: grey;
	  border-width: 0;
	  font-family: opensans;
	  font-size: 20px;
	}
</style>
</head>
<body>
	<body background="<?php echo base_url(); ?>assets/images/mountains.jpg">
	<div class="sidenav">
			<a href="<?php echo base_url('ddm/task')?>">Tasks</a>
			<a href="<?php echo base_url('ddm/calendar')?>">Calendar</a>
			<a href="<?php echo base_url('ddm/archive')?>">Archive</a>
			<a href="<?php echo base_url('ddm/profile')?>">Profile</a>
			<a href="<?php echo base_url('ddm/logout')?>">Logout</a>
	</div>
<div id="addTask">
	<h1>Input Data</h1>
    <form action="<?php echo base_url().'ddm/simpanTask';?>" method="POST" class="task">
        <table>
            <tr>
                <td width='25%'>Label</td>
                <td width='75%'><input type='text' name='label' class='lbl'></td>
            </tr>
            <tr>
                <td>Title   </td>
                <td><input type='text' name='title' class='tit'></td>
            </tr>
            <tr>
                <td>Description </td>
                <td><textarea type='text' name='description' class='desc	'></textarea></td>
            </tr>
        </table>
				<div id="taskSave" style='margin-top: 10px'>
			      <input type="submit" name="save" value="Save">
			  </div>
    </form>
</div>
<div class='footer' style="margin-left: 15%; width: 85%">
	<p>&copy; Nathan & Stephen</p>
</div>
</body>
</html>
