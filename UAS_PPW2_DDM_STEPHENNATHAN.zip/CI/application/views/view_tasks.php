<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
<title>Tasks</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" />
<style>
@font-face {
  font-family: futura light;
  src: url(<?= base_url()?>assets/fonts/futura light bt.ttf);
  font-family: opensans;
  src: url(<?= base_url()?>assets/fonts/OpenSans-Light.ttf);
}

.labels {
  margin-left: 15%;
}

.taskBtn input {
  color: black;
  background-color: grey;
  border-width: 0;
  font-family: opensans;
  font-size: 20px;
}

.taskTable {
  margin-top: 20px;
}

</style>
</head>
  <body background="<?php echo base_url(); ?>assets/images/mountains.jpg">
  <div class="sidenav">
      <a href="#task">Tasks</a>
      <a href="<?php echo base_url('ddm/archive')?>">Archive</a>
      <a href="<?php echo base_url('ddm/profile')?>">Profile</a>
      <a href="<?php echo base_url('ddm/logout')?>">Logout</a>
  </div>
  <div class="taskBtn" style="margin: 20px 0px 0px 17%">
    <form action="<?php echo base_url().'ddm/addTask';?>">
      <input type=submit name="addTask" value="Add Task">
  </div>
  <center><div style="height: 100%" class="labels">
    <table border='1' class='taskTable'>
        <?php
        $total=0;
        foreach($tasks as $listTask){
            $total++;?>
        <tr>
            <td><?php echo $listTask->label?></td>
            <td><?php echo $listTask->title?></td>
            <td height='100px'><?php echo $listTask->description?></td>
            <td><a href="<?php echo base_url().'ddm/edit/'.$listTask->label;?>">Edit</a> ||
                <a href="<?php echo base_url().'ddm/hapus_data/'.$listTask->label;?>">Delete</a>
            </td>
        </tr>
        <?php }?>
    </table>
  </center></div>

  <div class='footer' style="margin-left: 15%; width: 85%">
    <p>&copy; Nathan & Stephen</p>
  </div>
</body>
</html>
