<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
<title>Sign In</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href=<?= base_url()?>"assets/css/style.css">
<style type="text/css">
@font-face {
  font-family: futura light;
  src: url(<?= base_url()?>assets/fonts/futura light bt.ttf);
  font-family: opensans;
  src: url(<?= base_url()?>assets/fonts/OpenSans-Light.ttf);
}

body {
  margin:0;
}

footer {
  margin: 0;
  color: white;
  background-color: black;
  text-align: center;
  width: 100%;
  opacity: 0.7;
  display: inline-block;
}

div {
  align-content: center;
}

h1, h2, form, a {
  font-family: opensans;
}


input {
  height: 35px;
  width: 300px;
  font-size: 18px;
}

.navbar {
  overflow: hidden;
  background-color: grey;
  opacity: 0.9;
  position: fixed;
  top: 0;
  width: 100%;
}

.navbar a {
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
  font-family: opensans;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}
</style>
</head>
<?php
if (isset($logout_message)) {
echo "<div class='message'>";
echo $logout_message;
echo "</div>";
}
?>
<?php
if (isset($message_display)) {
echo "<div class='message'>";
echo $message_display;
echo "</div>";
}
?>
<body background="<?php echo base_url(); ?>assets/images/gradient.jpeg">
  <div class="navbar">
    <a href="<?php echo base_url('ddm')?>">Home</a>
  </div>
<center><div style="margin-top: 100px; height: 600px ">
  <div id="main">
  <div id="login">
    <h1>Sign In</h1></br>
    <?php echo form_open('ddm/task'); ?>
    <?php
    echo "<div class='error_msg'>";
    if (isset($error_message)) {
    echo $error_message;
    }
    echo validation_errors();
    echo "</div>";
    ?>
    <label>Email :</label></br>
    <input type="text" name="email" id="email" placeholder="Enter your email"/></br></br>
    <label>Password :</label ></br>
    <input type="password" name="password" id="password" placeholder="***************"/></br></br>
    <input type="submit" value="Login" name="submit"/></br>
    <a href="<?php echo base_url('ddm/new_user_regis') ?>">Don't have an account?</a>
    <?php echo form_close(); ?>
  </div>
  </div>
</center></div>
  <footer>
    <p>&copy; Nathan & Stephen</p>
  </footer>
</body>
</html>
