<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
<title>Profile</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" />
<style>
@font-face {
  font-family: futura light;
  src: url(<?= base_url()?>assets/fonts/futura light bt.ttf);
  font-family: opensans;
  src: url(<?= base_url()?>assets/fonts/OpenSans-Light.ttf);
}
#profile {
  width: 75%;
  margin-left: 20%;
  margin-right: auto;
  border-radius: 10px;
  overflow: hidden;
}

#subDiv1, #subDiv2 {
  width: 45%;
  border-width: 1px;
  border-color: white;
  border-style: solid;
  box-sizing: border-box;
  background-color: white;
  color: black;
  font-family: opensans;
}

#subDiv1 {
  margin-left: 20px;
  float: left;
}

#subDiv2 {
  margin-right: 20px;
  float: right;
}

form {
    float: left;
    text-align: left;
    margin-left: 40px;
}

input {
  height: 30px;
  width:250px;
  font-size: 18px;
}

#save {
  width: 100%;
}
}
</style>
</head>
  <body background="<?php echo base_url(); ?>assets/images/mountains.jpg">
    <div class="sidenav">
      <a href="<?php echo base_url('ddm/task')?>">Tasks</a>
      <a href="<?php echo base_url('ddm/archive')?>">Archive</a>
      <a href="#task">Profile</a>
      <a href="<?php echo base_url('ddm/logout')?>">Logout</a>
    </div>
  <center><div style="margin-top: 100px; height: 700px; color: white" id='profile'>
    <div id='subDiv1'>
      <h1 style="font-size:40px; font-face: bold">Profile Data</h1><br>
      <form action="/action_page.php" style="font-size: 24px">
        Email <br><input type="text" name="email"><br><br>
        Username <br><input type="text" name="username"><br><br>
        </br>
      </form>
      <input type="submit" value="Save" id='save'>
    </div>

    <div id='subDiv2'>
      <h1 style="font-size:40px; font-face: bold">Change Password</h1><br>
      <form action="/action_page.php" style="font-size: 24px">
        Old Password <br><input type="text" name="oldPass"><br></br>
        New Password <br><input type="text" name="newPass"><br></br>
        </br>
      </form>
      <input type="submit" value="Save" id='save'>
    </div>

  </div></center>
  <div class='footer'>
    <p>&copy; Nathan & Stephen</p>
  </div>
</body>
</html>
