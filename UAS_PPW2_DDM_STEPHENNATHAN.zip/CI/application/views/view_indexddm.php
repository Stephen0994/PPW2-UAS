<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">
@font-face {
  font-family: futura light;
  src: url(assets/fonts/futura light bt.ttf);
  font-family: opensans;
  src: url(assets/fonts/OpenSans-Light.ttf);
}

body  {
  margin: 0;
}

div {
  overflow: auto;
}

footer {
  margin: 0;
  color: white;
  background-color: black;
  text-align: center;
  width: 100%;
  opacity: 0.7;
  display: inline-block;
}

h1, h2, h3, p {
  font-family: opensans;
}

.about {
   word-wrap: break-word;
   width: 800px;
   text-align: justify;
   -moz-text-align-last: center;
    text-align-last: center;
}
.parallax {
    background-image: url("assets/images/workplace.png");
    min-height: 700px;
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    overflow: auto;
}

.navbar {
  overflow: hidden;
  background-color: grey;
  opacity: 0.9;
  position: fixed;
  top: 0;
  width: 100%;
}

.navbar a {
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
  font-family: opensans;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}
</style>
</head>
<body>
  <div class="navbar">
    <a href="<?php echo base_url(). 'ddm/signin' ?>">Sign In</a>
  </div>
  <div class="parallax">
    <center><h1 style="color:white; font-size:50px; margin-top:250px">Managing Deadlines</h1></center>
    <center><h1 style="color:white; font-size:50px">Made Easy</h1></center>
    <a href="<?php echo base_url('ddm/signup')?>">
      <center><button type="button" style="font-size:30px">GET STARTED</button></center>
    </a>
  </div>
  <div style="height:1000px;background-image: linear-gradient(rgba(255,255,255,0), rgba(150,150,150,1))">
    <center><h2 style="margin-top:400px; font-size:40px">ABOUT DDM</h2></center>
    <center><h3 class="about" style="font-size:30px">DDM is task management app for your everyday use.
     Starting from organizing your school work, work deadlines, so on and so forth.</h3></center>
  </div>
  <footer>
    <p>&copy; Nathan & Stephen</p>
  </footer>
</body>
</html>
