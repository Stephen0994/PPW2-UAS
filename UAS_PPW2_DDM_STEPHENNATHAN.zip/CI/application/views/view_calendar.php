<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <title>Calendar</title>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" />
        <link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="<?php echo base_url() ?>scripts/fullcalendar/fullcalendar.min.css" />
               <script src="<?php echo base_url() ?>scripts/fullcalendar/lib/moment.min.js"></script>
               <script src="<?php echo base_url() ?>scripts/fullcalendar/fullcalendar.min.js"></script>
               <script src="<?php echo base_url() ?>scripts/fullcalendar/gcal.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <style>
        @font-face {
          font-family: futura light;
          src: url(<?= base_url()?>assets/fonts/futura light bt.ttf);
          font-family: opensans;
          src: url(<?= base_url()?>assets/fonts/OpenSans-Light.ttf);
        }

        .container {
          margin-top: 30px;
        }

        table{
          border: 15px solid #818181;
          border-collapse:collapse;
          margin-top: 20px;
          margin-left: 15%;
          height: 550px;
          width: 85%;
        }

        td{
          width: 50px;
          height: 50px;
          border: 1px solid #e2e0e0;
          font-size: 18px;
          font-weight: bold;
        }

        th{
          background-color: black;
          color: white;
          height: 50px;
          padding-bottom: 8px;
          background: #818181;
          font-size: 20px;
          text-align: center;
        }

        .prev_sign a, .next_sign a{
          color:white;
          text-decoration: none;
        }

        tr.week_name{
          font-size: 16px;
          font-weight: bold;
          color: red;
          width: 10px;
          background-color: #ffffff;
        }

        .highlight{
          background-color:#25BAE4;
          color:white;
          height: 100%;
          width: 100%;
          text-align: center;
          padding-top: 24px;
        }
</style>
    </head>
    <body background="<?php echo base_url(); ?>assets/images/mountains.jpg">
    <div class="sidenav">
      <a href="<?php echo base_url('ddm/tasks')?>">Tasks</a>
      <a href="">Calendar</a>
      <a href="<?php echo base_url('ddm/archive')?>">Archive</a>
      <a href="<?php echo base_url('ddm/tasks')?>">Profile</a>
    </div>
    <div class="container">

      <?php
        echo $this->calendar->generate($year, $month);
      ?>
    </div>

    <div class='footer'>
      <p>&copy; Nathan & Stephen</p>
    </div>
<script type="text/javascript">
$(document).ready(function() {
  $('#calendar').fullCalendar({
    weekends: true
  });
});
</script>
    </body>
</html>
