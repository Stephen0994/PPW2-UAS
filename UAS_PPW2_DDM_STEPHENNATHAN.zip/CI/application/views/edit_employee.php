<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Form Edit Employee</title>
</head>
<body>
<div class="col-lg-6">
  <div class="card">
      <div class="card-header">
          <strong class="card-title">Master Employee</strong>
      </div>
      <div class="card-body">
        <!-- Credit Card -->
        <div id="pay-invoice">
            <div class="card-body">
                <div class="card-title">
                    <h3 class="text-center">Edit Employee</h3>
                </div>
                <hr>
                <form action="" method="post" novalidate="novalidate">
                    <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">Employee ID</label>
                        <input id="cc-pament" name="cc-payment" type="text" class="form-control" aria-required="true" aria-invalid="false" value="<?= $listEmployeeEdit->id ?>">
                    </div>
                    <div class="form-group has-success">
                        <label for="cc-name" class="control-label mb-1">Employee Name</label>
                        <input id="cc-name" name="cc-name" type="text" class="form-control cc-name valid" data-val="true"
												data-val-required="Please enter the name on card" autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error" value="<?= $listDosenEdit->name ?>">
                        <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                    </div>
                    <div class="form-group">
                        <label for="cc-number" class="control-label mb-1">Department</label>
                        <input id="cc-number" name="cc-number" type="tel" class="form-control cc-number identified visa"
												 value="" data-val="true" data-val-required="Please enter the card number" data-val-cc-number="Please enter a valid card number" autocomplete="cc-number" value="<?= $listDosenEdit->department ?>">
                        <span class="help-block" data-valmsg-for="cc-number" data-valmsg-replace="true"></span>
                    </div>
                    <div>
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                            <i class="fa fa-lock fa-lg"></i>&nbsp;
                            <span id="payment-button-amount">Submit</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
      </div>
  </div> <!-- .card -->
</div>
</body>
</html>
