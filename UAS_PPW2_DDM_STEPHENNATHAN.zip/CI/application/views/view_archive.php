<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
<title>Tasks</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" />
<style>
@font-face {
  font-family: futura light;
  src: url(<?= base_url()?>assets/fonts/futura light bt.ttf);
  font-family: opensans;
  src: url(<?= base_url()?>assets/fonts/OpenSans-Light.ttf);
}

.labels {
  margin-left: 15%;
}
</style>
</head>
  <body background="<?php echo base_url(); ?>assets/images/mountains.jpg">
  <div class="sidenav">
    <a href="<?php echo base_url('ddm/task')?>">Tasks</a>
    <a href="#task">Archive</a>
    <a href="<?php echo base_url('ddm/profile')?>">Profile</a>
    <a href="<?php echo base_url('ddm/logout')?>">Logout</a>
  </div>
  <center><div style="margin-top:100px; height: 100%" class="labels">
  <table>
    <tr style="background-color:grey">
      <th width="30%">Status</th>
      <th width="70%">Description</th>

    </tr>
    <tr>
      <td>Label 1<br>DD/MM/YYYY</td>
      <td>Assignment 1</td>

    </tr>
    <tr>
      <td>Label 1<br>DD/MM/YYYY</td>
      <td>Assignment 1</td>
    </tr>
    <tr>
      <td>Label 2<br>DD/MM/YYYY</td>
      <td>Assignment 2</td>
    </tr>
    <tr>
      <td>Label 2<br>DD/MM/YYYY</td>
      <td>Assignment 2</td>
    </tr>
    <tr>
      <td>Label 3<br>DD/MM/YYYY</td>
      <td>Assignment 3</td>
    </tr>
  </table>
  </center></div>
  <div class='footer'>
    <p>&copy; Nathan & Stephen</p>
  </div>
</body>
</html>
