<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
<title>Tasks</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@font-face {
  font-family: futura light;
  src: url(<?= base_url()?>assets/fonts/futura light bt.ttf);
  font-family: opensans;
  src: url(<?= base_url()?>assets/fonts/OpenSans-Light.ttf);
}

body, background {
  margin:0;
  background-repeat: no-repeat;
  background-size: cover;
}

footer {
  position: absolute;
  bottom: 0;
  margin: 0;
  color: white;
  background-color: black;
  text-align: center;
  width: 100%;
  opacity: 0.7;
}

h1 {
  font-family: opensans;
}


table {
    font-family: opensans;
    border-collapse: collapse;
    width: 60%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: center;
    font-size: 20px;
    padding: 8px;
}

td {
  background-color: white;
}

.labels {
  margin-left: 100px;
}

.navbar {
  overflow: hidden;
  background-color: grey;
  opacity: 0.9;
  position: fixed;
  top: 0;
  width: 100%;
  margin-left: 160px;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
  font-family: opensans;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}
.sidenav {
    height: 100%;
    width: 160px;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    padding-top: 20px;
    font-family: opensans;
}

.sidenav a {
    padding: 6px 8px 6px 16px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.main {
    margin-left: 160px; /* Same as the width of the sidenav */
    font-size: 28px; /* Increased text to enable scrolling */
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
    .sidenav a {font-size: 18px;}
}
</style>
</head>
  <body background="<?php echo base_url(); ?>assets/images/mountains.jpg">
  <div class="navbar">
    <a href="#task">All Notes</a>
    <a href="ddm/calendar">Label 1</a>
    <a href="ddm/calendar">Label 2</a>
    <a href="ddm/calendar">Label 3</a>
  </div>
  <center><div style="margin-top:100px; height: 100%" class="labels">
  <table>
    <tr style="background-color:grey">
      <th width="30%">Status</th>
      <th width="70%">Description</th>

    </tr>
    <tr>
      <td>Assignment 1</td>
      <td>Assignment 2</td>

    </tr>
    <tr>
      <td>Assignment 1</td>
      <td>Assignment 2</td>
    </tr>
    <tr>
      <td>Assignment 1</td>
      <td>Assignment 2</td>
    </tr>
    <tr>
      <td>Assignment 1</td>
      <td>Assignment 2</td>
    </tr>
    <tr>
      <td>Assignment 1</td>
      <td>Assignment 2</td>
    </tr>
  </table>
  </center></div>
  <div class="sidenav">
    <a href="#task">Tasks</a>
    <a href="<?php echo base_url('ddm/calendar')?>">Calendar</a>
    <a href="#task">Archive</a>
    <a href="#task">Profile</a>
  </div>
  <footer>
    <p>&copy; Nathan & Stephen</p>
  </footer>
</body>
</html>
