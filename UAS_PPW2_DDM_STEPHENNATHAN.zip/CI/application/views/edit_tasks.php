<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" />
	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }
	@font-face {
	  font-family: futura light;
	  src: url(<?= base_url()?>assets/fonts/futura light bt.ttf);
	  font-family: opensans;
	  src: url(<?= base_url()?>assets/fonts/OpenSans-Light.ttf);
	}

	#editTask {
	  margin-left: 17%;
	}

	.task a, td {
		background-color: transparent;
		text-align: left;
		border: 0;
	}

	.lbl, .tit {
		height: 20px;
	}

	.desc {
		height: 100px;
		width: 500px
	}

	#taskEdit input {
		color: black;
		background-color: grey;
		border-width: 0;
		font-family: opensans;
		font-size: 20px;
	}

	</style>
</head>
<body>
	<body background="<?php echo base_url(); ?>assets/images/mountains.jpg">
	<div class="sidenav">
			<a href="<?php echo base_url('ddm/task')?>">Tasks</a>
			<a href="<?php echo base_url('ddm/archive')?>">Archive</a>
			<a href="<?php echo base_url('ddm/profile')?>">Profile</a>
			<a href="<?php echo base_url('ddm/logout')?>">Logout</a>
	</div>
<div id="editTask">
	<h1>Edit Task</h1>
    <?php foreach($taskEdit as $listTaskEdit){ ?>
    <form action="<?php echo base_url().'ddm/update_data';?>" method="POST">
			<table>
					<tr>
							<td width='25%'>Label</td>
							<td width='75%'><input type='text' name='label' class='lbl' value="<?=$listTaskEdit->label?>" readonlytas></td>
					</tr>
					<tr>
							<td>Title   </td>
							<td><input type='text' name='title' class='tit' value='<?=$listTaskEdit->title?>'></td>
					</tr>
					<tr>
							<td>Description </td>
							<td><textarea type='text' name='description' class='desc' value="<?=$listTaskEdit->description?>"></textarea></td>
					</tr>
					<tr>
							<td>

									<input type="submit" name="submit" value="Edit">

							</td>
					</tr>
			</table>
    </form>
    <?php } ?>
</div>

<div class='footer' style="margin-left: 15%; width: 85%">
	<p>&copy; Nathan & Stephen</p>
</div>
</body>
</html>
