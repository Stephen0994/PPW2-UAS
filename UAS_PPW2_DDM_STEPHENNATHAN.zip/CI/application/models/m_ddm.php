<?php

class m_ddm extends CI_Model{

  public function registration_insert($data) {

  $condition = "user_name =" . "'" . $data['user_name'] . "'";
  $this->db->select('*');
  $this->db->from('user_login');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0) {

  $this->db->insert('user_login', $data);
  if ($this->db->affected_rows() > 0) {
  return true;
  }
  } else {
  return false;
  }
  }

  public function login($data) {

  $condition = "user_name =" . "'" . $data['username'] . "' AND " . "user_password =" . "'" . $data['password'] . "'";
  $this->db->select('*');
  $this->db->from('user_login');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();

  if ($query->num_rows() == 1) {
  return true;
  } else {
  return false;
  }
  }

  public function read_user_information($username) {

  $condition = "user_name =" . "'" . $username . "'";
  $this->db->select('*');
  $this->db->from('user_login');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();

  if ($query->num_rows() == 1) {
  return $query->result();
  } else {
  return false;
  }
  }

  function tampilkan_data(){
      return $this->db->get('tasks');
  }

  function insert_table($data, $table){
      $this->db->insert($table, $data);
  }

  function getTaskByAjax($where){
      $query=$this->db->get_where('tasks', $where);
      if($query->num_rows()>0){
          foreach($query->result() as $data){
              $output=array(
              'label' => $data->label,
              'title' => $data->title,
              'description' => $data->description);
          }
      }
      return $output;
  }


  function edit($where, $table){
      return $this->db->get_where($table, $where);
  }

  function update_data($where, $data, $table){
      $this->db->where($where);
      $this->db->update($table, $data);
  }

  function delete_data($where, $table){
      $this->db->where($where);
      $this->db->delete($table);
  }

}
