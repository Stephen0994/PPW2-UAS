<?php

class Calendar_Model extends CI_Model
{


}

?>
