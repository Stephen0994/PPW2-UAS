<?php
class m_jadwal extends CI_Model{
function selectData()
{
$this->db->getData();
}
}
