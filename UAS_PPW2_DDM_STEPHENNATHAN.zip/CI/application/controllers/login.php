<?php
class login extends CI_Controller{
	function __construct(){
		parent:: __construct();
		$this->load->model('m_login');
	}

	function index(){
	$this->load->view('view_login');
	}

	function proses_login(){
		$tangkapUsername = $this->input->post('username');
		$tangkapPassword = $this->input->post('password');
		$where = array(
			'username' => $tangkapUsername,
			'password' => md5($tangkapPassword)
		);
		$cek = $this->m_login->cek_login('admin', $where)->num_rows();
		if($cek > 0){
			$data_session = array(
				'nama' => $username
				);

			$this->session->set_userdata($data_session);
			redirect('enroll/index');
		}else{
			echo 'Username dan password yang anda masukan salah';
		}
	}
}
