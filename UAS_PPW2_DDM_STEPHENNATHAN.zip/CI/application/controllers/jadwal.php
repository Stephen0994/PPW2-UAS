<?php
defined ("BASEPATH") OR exit('No direct script access allowed');

class jadwal extends CI_Controller{
  fucntion __contruct(){
    parent::__contruct();
    $this->load->model(array('m_jadwal'));
  }

  function index(){
    $data['join'] = $this->m_jadwal->selectData()->result();
    $this->load->view('view_jadwal_dosen',$data);
  }
}
