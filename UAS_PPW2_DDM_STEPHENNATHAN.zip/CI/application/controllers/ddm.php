<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ddm extends CI_Controller {

  function __construct(){
		parent:: __construct();
		$this->load->model('m_ddm');
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library('session');
	}

  function index(){
  $this->load->view('view_indexddm');
  }

  function signin(){
  $this->load->view('view_signin');
  }

  public function signup() {
  $this->load->view('view_signup');
  }

  public function new_user_regis() {
  $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
  $this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
  $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
  if ($this->form_validation->run() == FALSE) {
  $this->load->view('view_signup');
  } else {
  $data = array(
  'user_name' => $this->input->post('username'),
  'user_email' => $this->input->post('email_value'),
  'user_password' => $this->input->post('password')
  );
  $result = $this->m_ddm->registration_insert($data);
  if ($result == TRUE) {
  $data['message_display'] = 'Registration Successfully !';
  $this->load->view('view_signin', $data);
  } else {
  $data['message_display'] = 'Username already exist!';
  $this->load->view('view_signup', $data);
  }
  }
  }

  public function user_login_process() {

  $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
  $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');

  if ($this->form_validation->run() == FALSE) {
  if(isset($this->session->userdata['logged_in'])){
  $this->load->view('view_tasks');
  }else{
  $this->load->view('view_signin');
  }
  } else {
  $data = array(
  'username' => $this->input->post('username'),
  'password' => $this->input->post('password')
  );
  $result = $this->m_ddm->login($data);
  if ($result == TRUE) {

  $username = $this->input->post('username');
  $result = $this->m_ddm->read_user_information($username);
  if ($result != false) {
  $session_data = array(
  'username' => $result[0]->user_name,
  'email' => $result[0]->user_email,
  );
  $this->session->set_userdata('logged_in', $session_data);
  $this->load->view('view_tasks');
  }
  } else {
  $data = array(
  'error_message' => 'Invalid Username or Password'
  );
  $this->load->view('view_signin', $data);
  }
  }
  }

  public function logout() {
  $sess_array = array(
  'username' => ''
  );
  $this->session->unset_userdata('logged_in', $sess_array);
  $data['message_display'] = 'Successfully Logout';
  $this->load->view('view_signin', $data);
  }

  function simpanTask(){
      $label = $this->input->post('label');
      $title = $this->input->post('title');
      $description = $this->input->post('description');

      $data=array(
      'label' => $label,
      'title' => $title,
      'description' => $description);
      $this->m_ddm->insert_table($data, 'tasks');
      redirect('ddm/task');
  }

  public function task() {
        $data['tasks'] = $this->m_ddm->tampilkan_data()->result();
        $this->load->view('view_tasks.php', $data);

  function helper(){
    echo hello();
  }
  }

  function addTask(){
  $this->load->view("add_tasks");
  }

  function edit($label){
      $where = array('label' => $label);
      $data['taskEdit'] = $this->m_ddm->edit($where, 'tasks')->result();
      $this->load->view("edit_tasks", $data);
  }

  function update_data(){
      $label = $this->input->post('label');
      $title = $this->input->post('title');
      $description = $this->input->post('description');

      $data=array(
        'label' => $label,
        'title' => $title,
        'description' => $description);

      $where = array('label' => $label);

      $this->m_ddm->update_data($where, $data, 'tasks');
      redirect('ddm/task');
  }

  function hapus_data($label){
      $where = array('label'=>$label);
      $this->m_ddm->delete_data($where, 'tasks');
      redirect('ddm/task');
  }

  function archive(){
  $this->load->view("view_archive");
  }

  function profile(){
  $this->load->view("view_profile");
  }


}
