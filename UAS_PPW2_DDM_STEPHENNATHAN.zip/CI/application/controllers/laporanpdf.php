<?php
Class laporanpdf extends CI_Controller{

  function __construct(){
    parent::__construct();
    $this->load->model('m_dosen');
    $this->load->library('pdf');
  }

  function index(){
    $pdf = new FPDF('l', 'mm', 'A5');
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', '18');
    $pdf->Cell(190, 7, 'Data Dosen', 0, 1, 'C');
    $pdf->Cell(10, 6, 0, 1);
    $pdf->SetFont('Arial', 'B', '10');
    $pdf->Cell(20, 6, 'NIK', 1, 0);
    $pdf->Cell(60, 6, 'NAMA', 1, 0);
    $pdf->Cell(40, 6, 'Jurusan', 1, 0);
    $pdf->Cell(60, 6, 'Email', 1, 1);
    $pdf->SetFont('Arial', '', '10');
    $pdf->output();
  }
}
?>
