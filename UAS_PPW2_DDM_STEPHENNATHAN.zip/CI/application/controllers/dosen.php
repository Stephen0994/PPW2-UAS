<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dosen extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('m_dosen');
	}
	
	public function index(){
		$data['dosen'] = $this->m_dosen->selectData()->result();
		$this->load->view('view_dosen.php', $data);
	}

	function tambahDosen(){
		$this->load->view('form_tambah_dosen.php');
	}

	function simpanDosen(){
		$tangkapNIK = $this->input->post('nik');
		$tangkapNama = $this->input->post('nama');
		$tangkapJurusan = $this->input->post('jurusan');
		$tangkapEmail = $this->input->post('email');

		$data = array(
			'nik'=>$tangkapNIK,
			'nama'=>$tangkapNama,
			'jurusan'=>$tangkapJurusan,
			'email'=>$tangkapEmail,
		);

		$this->m_dosen->insertData($data,'dosen');
		redirect('dosen/index');
	}
	
	function edit($nik){
		$where = array('nik' => $nik);
		$data['dosenEdit'] = $this->m_dosen->edit($where,'dosen')->result();
		$this->load->view('edit_dosen.php', $data);
	}
	
	function update_data(){
		$tangkapNIK = $this->input->post('nik');
		$tangkapNama = $this->input->post('nama');
		$tangkapJurusan = $this->input->post('jurusan');
		$tangkapEmail = $this->input->post('email');
		
		$data = array(
			'nik' => $tangkapNIK,
			'nama' => $tangkapNama,
			'jurusan' => $tangkapJurusan,
			'email' => $tangkapEmail,
		);
		
		$where = array(
			'nik' => $tangkapNIK
		);
		
		$this->m_dosen->update_data($where,$data,'mahasiswa');
		redirect('dosen/index');
	}
	
	function hapus_data($nik){
		$where = array('nik' => $nik);
		$this->m_dosen->delete_data($where,'dosen');
		redirect('dosen/index');
	}
}
